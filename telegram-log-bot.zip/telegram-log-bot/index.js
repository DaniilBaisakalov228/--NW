const { Telegraf } = require("telegraf");

const TOKEN = "8358251838:AAH8ToDLjlyy6O5CYpbJBBQE9oMYx0hG3mA";
const LOG_CHAT_ID = -1003851668163;

if (!TOKEN || TOKEN.length < 10) {
  console.error("❌ Укажи токен бота");
  process.exit(1);
}

const bot = new Telegraf(TOKEN);

bot.catch((err) => console.error("BOT ERROR:", err));

function formatUser(user) {
  if (!user) return "unknown";
  const username = user.username ? `(@${user.username})` : "";
  const name = `${user.first_name || ""} ${user.last_name || ""}`.trim();
  return `${name} ${username}`.trim();
}

function formatDate(unix) {
  if (!unix) return "навсегда";
  return new Date(unix * 1000).toLocaleString("ru-RU");
}

function isMuted(member) {
  return (
    member?.status === "restricted" &&
    member?.can_send_messages === false
  );
}

async function sendLog(text) {
  try {
    await bot.telegram.sendMessage(LOG_CHAT_ID, text, {
      parse_mode: "HTML"
    });
  } catch (e) {
    console.error("Ошибка отправки лога:", e.message);
  }
}

bot.start((ctx) => ctx.reply("Лог-бот работает ✅"));
bot.command("ping", (ctx) => ctx.reply("pong 🏓"));

bot.on("chat_member", async (ctx) => {

  const data = ctx.update.chat_member;
  if (!data) return;

  const actor = data.from;
  const user = data.new_chat_member?.user;

  const oldMember = data.old_chat_member;
  const newMember = data.new_chat_member;

  if (!user || !oldMember || !newMember) return;

  const oldStatus = oldMember.status;
  const newStatus = newMember.status;

  let message = null;

  if ((oldStatus === "left" || oldStatus === "kicked") && newStatus === "member") {

    if (data.invite_link) {
      const creator = data.invite_link.creator;
      const linkName = data.invite_link.name;

      message = `➕ <b>Вход</b>
👤 ${formatUser(user)}
🔗 По ссылке: ${formatUser(creator)}
${linkName ? `🏷 Название ссылки: ${linkName}` : ""}`;
    }

    else if (actor && actor.id !== user.id) {
      message = `➕ <b>Вход</b>
👤 ${formatUser(user)}
👮 Добавил: ${formatUser(actor)}`;
    }

    else {
      message = `➕ <b>Вход</b>
👤 ${formatUser(user)}
🔗 Вступил самостоятельно`;
    }
  }

  else if (oldStatus === "member" && newStatus === "left") {
    message = `➖ <b>Выход</b>
👤 ${formatUser(user)}`;
  }

  else if (newStatus === "kicked") {
    message = `🚫 <b>БАН</b>
👤 ${formatUser(user)}
🤖 Действие выполнено: ${formatUser(actor)}`;
  }

  else if (oldStatus === "kicked" && newStatus === "left") {
    message = `✅ <b>РАЗБАН</b>
👤 ${formatUser(user)}
🤖 Действие выполнено: ${formatUser(actor)}`;
  }

  else {

    const wasMuted = isMuted(oldMember);
    const nowMuted = isMuted(newMember);

    if (!wasMuted && nowMuted) {
      message = `🔇 <b>МУТ</b>
👤 ${formatUser(user)}
🤖 Действие выполнено: ${formatUser(actor)}
⏳ До: ${formatDate(newMember.until_date)}`;
    }

    else if (wasMuted && !nowMuted) {
      message = `🔊 <b>РАЗМУТ</b>
👤 ${formatUser(user)}
🤖 Действие выполнено: ${formatUser(actor)}`;
    }
  }

  if (message) {
    await sendLog(message);
  }
});

(async () => {
  try {

    await bot.telegram.deleteWebhook({ drop_pending_updates: true });

    const me = await bot.telegram.getMe();
    console.log(`✅ Бот запущен: @${me.username}`);

    await sendLog("🚀 Лог-бот успешно запущен");

    await bot.launch({
      allowedUpdates: ["chat_member", "my_chat_member"]
    });

  } catch (err) {
    console.error("❌ Ошибка запуска:", err.message);
  }
})();